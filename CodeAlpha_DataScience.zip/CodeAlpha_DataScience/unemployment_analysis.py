"""CodeAlpha Task 2: Unemployment Analysis with Python.
Run: python unemployment_analysis.py
Dependencies: pandas, matplotlib
"""
from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parent
DATA = ROOT / "data" / "Unemployment in India.csv"
OUT = ROOT / "results"
OUT.mkdir(exist_ok=True)
df = pd.read_csv(DATA)
df.columns = df.columns.str.strip()
df["Date"] = pd.to_datetime(df["Date"].astype(str).str.strip(), format="%d-%m-%Y", errors="coerce")
rate_col = "Estimated Unemployment Rate (%)"
df[rate_col] = pd.to_numeric(df[rate_col], errors="coerce")
df = df.dropna(subset=["Date", rate_col]).copy()
df = df.sort_values("Date")
df["YearMonth"] = df["Date"].dt.to_period("M").dt.to_timestamp()
monthly = df.groupby("YearMonth", as_index=False)[rate_col].mean()
monthly.to_csv(OUT / "monthly_unemployment_average.csv", index=False)

plt.figure(figsize=(10, 5))
plt.plot(monthly["YearMonth"], monthly[rate_col], marker="o", markersize=3)
plt.axvline(pd.Timestamp("2020-03-01"), linestyle="--", label="COVID-19 period marker (Mar 2020)")
plt.title("Average Estimated Unemployment Rate in India")
plt.xlabel("Month")
plt.ylabel("Unemployment rate (%)")
plt.grid(alpha=.25)
plt.legend()
plt.tight_layout()
plt.savefig(OUT / "unemployment_monthly_trend.png", dpi=160)
plt.close()

# Compare the dataset's available pre-pandemic and pandemic-period records.
df["Period"] = df["Date"].apply(lambda d: "Before Mar 2020" if d < pd.Timestamp("2020-03-01") else "Mar 2020 onward")
summary = df.groupby("Period")[rate_col].agg(["count", "mean", "median", "min", "max"]).round(2)
summary.to_csv(OUT / "unemployment_period_summary.csv")
summary.to_string()
summary.plot(y="mean", kind="bar", legend=False, color=None)
plt.title("Mean Unemployment Rate by Period")
plt.ylabel("Mean estimated unemployment rate (%)")
plt.xlabel("")
plt.xticks(rotation=0)
plt.tight_layout()
plt.savefig(OUT / "unemployment_period_comparison.png", dpi=160)
plt.close()

region = df.groupby("Region")[rate_col].mean().sort_values(ascending=False).round(2)
region.rename("Mean estimated unemployment rate (%)").to_csv(OUT / "regional_average.csv")

print("Rows analyzed:", len(df))
print("Date range:", df["Date"].min().date(), "to", df["Date"].max().date())
print("Period summary:\n", summary)
print("Regional averages saved in results/regional_average.csv")
print("Caution: these are descriptive comparisons, not proof that COVID-19 alone caused observed changes.")
