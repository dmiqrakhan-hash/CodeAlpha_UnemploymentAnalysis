"""CodeAlpha Task 1: Iris Flower Classification.
Run: python iris_classification.py
Dependencies: pandas, scikit-learn, matplotlib
"""
from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import accuracy_score, classification_report, ConfusionMatrixDisplay

ROOT = Path(__file__).resolve().parent
DATA = ROOT / "data" / "Iris.csv"
OUT = ROOT / "results"
OUT.mkdir(exist_ok=True)

df = pd.read_csv(DATA)
features = ["SepalLengthCm", "SepalWidthCm", "PetalLengthCm", "PetalWidthCm"]
X = df[features]
y = df["Species"]
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)
model = DecisionTreeClassifier(random_state=42)
model.fit(X_train, y_train)
pred = model.predict(X_test)
accuracy = accuracy_score(y_test, pred)
report = classification_report(y_test, pred, zero_division=0)
(OUT / "iris_metrics.txt").write_text(
    f"Test set size: {len(y_test)}\nAccuracy: {accuracy:.4f} ({accuracy:.1%})\n\n{report}\n",
    encoding="utf-8"
)
ConfusionMatrixDisplay.from_predictions(y_test, pred, xticks_rotation=30)
plt.title("Iris Classification — Confusion Matrix")
plt.tight_layout()
plt.savefig(OUT / "iris_confusion_matrix.png", dpi=160)
plt.close()
print(f"Test accuracy: {accuracy:.1%}")
print(report)
print("Saved metrics and confusion matrix in results/")
