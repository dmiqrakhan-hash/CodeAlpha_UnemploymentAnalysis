# CodeAlpha Data Science Internship — Two Tasks

This repository contains the completed code and outputs for two tasks from the CodeAlpha Data Science internship brief.

## Task 1 — Iris Flower Classification
A Decision Tree classifier predicts Iris species from four flower measurements. The script uses a stratified 80/20 train/test split and reports test accuracy, a classification report, and a confusion-matrix plot.

Run from this folder:
```bash
pip install -r requirements.txt
python iris_classification.py
```

## Task 2 — Unemployment Analysis with Python
The script cleans the supplied India unemployment CSV, calculates monthly averages, plots the trend, compares records before March 2020 with records from March 2020 onward, and exports regional averages.

```bash
python unemployment_analysis.py
```

The analysis uses `data/Unemployment in India.csv`. A second related dataset is included in `data/Unemployment_Rate_upto_11_2020.csv` as received, but the script's main analysis uses the first file because it includes the `Area` field and the task asks for unemployment trends. The data cover a limited historical period; results are descriptive and do not establish causation.

## Files
- `data/`: source CSV files supplied for the tasks
- `results/`: generated metrics, summary tables, and figures
- `iris_classification.py`: Task 1 script
- `unemployment_analysis.py`: Task 2 script

## Dependencies
See `requirements.txt`.
